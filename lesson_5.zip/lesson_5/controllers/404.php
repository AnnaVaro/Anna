<?php

require_once "../lib/Controller.php";

class Ctrl404 extends Controller {
    public function actionIndex () {

    }
}
